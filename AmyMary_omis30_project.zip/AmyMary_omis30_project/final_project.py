import pandas as pd
import requests
import time
from bs4 import BeautifulSoup
from selenium.webdriver import Chrome
import re
from xpath_string.xpath import Xpath
from selenium.webdriver.common.action_chains import ActionChains
webdriver = r'/Users/Mrkayee/Desktop/OMIS30/chromedriver'
universities_url='https://www.usnews.com/best-colleges/rankings/national-universities'

driver = Chrome(webdriver)
r = driver.get(universities_url)
driver.page_source
Main_Page_soup = BeautifulSoup(driver.page_source)

#This while loop asks the webpage to scroll down 30 times. 
#And the website will load out more schools.
t=0
while t < 30:
    driver.execute_script("window.scrollTo(0, window.scrollY + 4000)")
    t+=1
    time.sleep(5)

#We read the website again since more schools have been loaded the web code changes as well
driver.page_source  
All_Info_Soup = BeautifulSoup(driver.page_source)

#We start the first round of scraping 
#we scrape for the link for clicking into different schools's US News tabs
main_body=All_Info_Soup.find('main',id="app")
school=main_body.find('ol', class_="ResultsCards__OrderedList-s29uvb-0 fxaDYp")
school_tab=school.find_all('li')
#We declare and variable here because we want to know how many schools it found
count=len(school_tab)


All_Click_list=[]
MasterList=[]
#We use a for loop to find information for each school's US News page
#We skipped on line because each school have two 'li' started code 
    # -- one has the link and the other one had ranking information
# And we only need the link for scraping.
for i in range (0,count,2):
    school_click_list=[]
    school_detail=school_tab[i].find('a', class_="card-name DetailCardColleges__StyledAnchor-s17yhmce-6 ktKikb Anchor-s1mkgztv-0 jUurly")
    school_name=school_detail.text
    school_click_list.append(school_name)

    School_Links=school_detail.get('href')
    school_page="https://www.usnews.com"+School_Links
#     print(type(school_page))
# Once we find the link, we want to open each page and scrapge for more info
    SchoolList=[]
    driver = Chrome(webdriver)
    new_r=driver.get(school_page)
    #We give the website 5 seconds to load
    time.sleep(5)
    #Now we want to read the new opened page
    driver.page_source
    new_soup = BeautifulSoup(driver.page_source)
    
    try:

        new_main=new_soup.find('main',id='app')
        second_level_div=new_main.find('div', class_="Reset-s1kkixp-0 hUPScg")
        third_level_div=second_level_div.find('div',class_='Content-s19yd3ga-0 content KBvih')
        MainColumn=third_level_div.find('div',class_='Villain__MainColumn-pv90bm-1 ecFFWE')
        SubMainColumn=MainColumn.find('div',class_='Villain__Content-pv90bm-4 fJcEHY')

        School_Title=SubMainColumn.find('div',class_='Villain__TitleContainer-pv90bm-6 dMmjyj')
        Name=School_Title.text  #Get school name

        adr=SubMainColumn.find('p',class_='Hide-s1x4faml-0 iGesMc Paragraph-s10q84gy-0 cXvmiD')
        address=adr.text    #Get school address and contact info

        rank=SubMainColumn.find('span',class_='ProfileHeading__RankingSpan-oe1kcz-3 cythWu')
        ranking=rank.text   #Get ranking

        forth_level_div=third_level_div.find('div',class_='Villain__SupplementColumn-pv90bm-2 iIVfEX')
        table1=forth_level_div.find('span',class_='Span-aabx0k-0 dQozDW')
        tuition=table1.text #Get tuition

        general_info=second_level_div.find('div',class_='Cell-ob8sob-0 ejFJHg')
        All_Info=general_info.find_all('p',class_='Paragraph-s10q84gy-0 flDDtn')

        general_info_list=[]
        for lines in All_Info:
            general_info_list.append(lines.text)
        school_type=general_info_list[0]    #Get school type
        religious_affilation=general_info_list[2]   #Get religious affiliation
        Setting=general_info_list[4]    #Get school setting

        admission_info=new_main.find('div',class_='mb0 Cell-ob8sob-0 bihNYE')
        admissions=admission_info.find_all('p',class_='Section__DataCell-s1m2i9oc-2 hKMugH Paragraph-s10q84gy-0 ezqrTu')

        admission_info_list=[]
        for l in admissions:
            admission_info_list.append(l.text)
        selectivity=admission_info_list[1]  #Get school selectivity
        student_faculty_ratio=admission_info_list[5]    #Get student-faculty ratio
        atheletic_association=admission_info_list[8]    #Get atheletic association
        acceptance_rate=admission_info_list[2]  #  Get acceptance rate

        #Append all the info into a list
        SchoolList.append(Name)
        SchoolList.append(address)
        SchoolList.append(ranking)
        SchoolList.append(selectivity)
        SchoolList.append(student_faculty_ratio)
        SchoolList.append(atheletic_association)
        SchoolList.append(acceptance_rate)
        SchoolList.append(school_type)
        SchoolList.append(religious_affilation)
        SchoolList.append(Setting)
        SchoolList.append(tuition)

        # print(SchoolList)
        #Append all school list to a Master list
        MasterList.append(SchoolList)
    
    except:
        time.sleep(3)
    #Close the tab
    driver.close()
#     time.sleep(5)

#MasterList

#Create headers for the dataframe
headers=[]
headers.append('School Name')
headers.append('School Address | Contact Info')
headers.append('Ranking')
headers.append('Selectivity')
headers.append('Student Faculty Ratio')
headers.append('Atheletic Association')
headers.append('Acceptance Rate')
headers.append('School Type')
headers.append('Religious Affilation')
headers.append('Setting')
headers.append('Tuition')

[headers]+MasterList

import random
random.randint(0,1)
#Create the pandas dataframe and donwload the dataframe into a csv file
pd.DataFrame
df = pd.DataFrame([headers] + MasterList)
df = pd.DataFrame(MasterList, columns = headers)
df.to_csv('/Users/MrKayee/Desktop/NewData.csv')