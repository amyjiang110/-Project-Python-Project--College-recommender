
# import the Flask class from the flask module
from flask import Flask, render_template, request
import pandas as pd, re

# create the application object
app = Flask(__name__)

# use decorators to link the function to a url

@app.route('/')
def home():
    return render_template('Website.html')


@app.route('/Preference', methods=['get','post'])
def Recommendation():
    #IMPORT PANDAS DATAFRAME WHICH CONTAINS ALL THE SCHOOL INFO WE WILL NEED
    CollegeData = pd.read_csv('./NationalUniversityData.csv')


    #IMPORT USER INPUT FROM THE HTML FORM ON THE WEBSITE
    Student_GPA = request.args['GPA']
    Student_Region = request.args['Region']
    Student_Budget = request.args['Budget']
    Student_TopSchools = request.args['TopSchools']


    #EXTRACT THE USEFUL PARTS OF THE INFORMATION SCRAPED FROM THE ORIGINAL DATAFRAME AND PUT THEM IN NEW COLUMNS
    CollegeData['Tuition_new'] = (((CollegeData['Tuition'].str.split('(').str[0]).str.split('$').str[1]).str.replace(',','')).str.rstrip()
    CollegeData['StateLocation'] = ((CollegeData['School Address | Contact Info'].str.split('|').str[0]).str.split(',').str[-1]).str.split(' ').str[1]
    CollegeData['Ratio_New'] = CollegeData['Student Faculty Ratio'].str.split(':').str[0]
    
    #USE STUDENT'S GPA FOR SELECTIVENESS ANALYSIS
    # We compared the Student GPA with the selectiveness of colleges 
    if Student_GPA=='3.80 ~ 4.0':
        School_Selectiveness=CollegeData[(CollegeData['Selectivity']=='Most selective' ) |
                                         (CollegeData['Selectivity']=='More selective' ) | 
                                         (CollegeData['Selectivity']=='selective')]
    elif Student_GPA=='3.30 ~ 3.79':
        School_Selectiveness=CollegeData[(CollegeData['Selectivity']=='More selective' ) |
                                         (CollegeData['Selectivity']=='selective' ) | 
                                         (CollegeData['Selectivity']=='Less selective') ]
    elif Student_GPA=='3.00 ~ 3.30':
        School_Selectiveness=CollegeData[(CollegeData['Selectivity']=='selective' ) | 
                                         (CollegeData['Selectivity']=='Less selective') |
                                         (CollegeData['Selectivity']=='Least selective') ]
    elif Student_GPA=="Below 2.99":
        School_Selectiveness=CollegeData[(CollegeData['Selectivity']=='Less selective') |
                                         (CollegeData['Selectivity']=='Least selective') ]
    
    #USE STUDENT'S BUDGET FOR TUITION ANALYSIS
    #we compre the Student budget with each schools tuition cost
    #filter out the schools that the student can not afford
    if Student_Budget=='MoreThan50000':
        School_Budget = School_Selectiveness
    elif Student_Budget=='LessThan50000':
        School_Budget = School_Selectiveness [pd.to_numeric(CollegeData['Tuition_new'])<=50000]
    elif Student_Budget=='LessThan40000':
        School_Budget = School_Selectiveness [pd.to_numeric(CollegeData['Tuition_new'])<=40000]
    elif Student_Budget=="LessThan30000":
        School_Budget = School_Selectiveness [pd.to_numeric(CollegeData['Tuition_new'])<=30000]



    #CATEGORIZE SATES INTO REGIONS
    West= ['CA','NV','WA','OR','ID','MT','WY','UT','CO','AL','HI']
    Northeast=['ME','VT','NH','NY','PA','MA','RI','CT','NJ','DE','MD']
    Southeast=['WV','VA','KY','TN','NC','SC','AR','LA','MS','AL','GA','FL']
    Midwest= ['ND','SD','NE','KS','MN','IA','MO','WI','IL','IN','MI','OH']
    Southwest= ['AZ','NM','TX','OK']
    #filter out the schools that are not in the student's preferred region.
    if Student_Region=='West':
        School_Region = School_Budget[School_Budget.StateLocation.isin(West)]
    elif Student_Region=='Northeast':
        School_Region = School_Budget[School_Budget.StateLocation.isin(Northeast)]
    elif Student_Region=='Southeast':
        School_Region = School_Budget[School_Budget.StateLocation.isin(Southeast)]
    elif Student_Region=="Midwest":
        School_Region = School_Budget[School_Budget.StateLocation.isin(Midwest)]
    elif Student_Region=='Southwest':
        School_Region = School_Budget[School_Budget.StateLocation.isin(Southwest)]
    elif Student_Region=='000':
        School_Region=School_Budget

    # Delete the extra columns that were extracted and used earlier.
    ForDisplay = School_Region.drop(columns= 'StateLocation')
    ForDisplay = ForDisplay.drop(columns='Tuition_new')
    ForDisplay = ForDisplay.drop(columns='Ratio_New')
    ForDisplay = ForDisplay.drop(columns='Unnamed: 0')
    ForDisplay = ForDisplay.drop(columns='Selectivity')
    ForDisplay['Tuition'] = ((CollegeData['Tuition'].str.split('(').str[0]))


    # Check if Dataframe is empty using empty attribute
    # If it is empty, generate all schools that match their GPA and a note for explanation 
    NoteForNone=' '
    if pd.isnull(ForDisplay.iloc[1,0])==True:
        ForDisplay = School_Selectiveness.drop(columns='Unnamed: 0')
        ForDisplay = ForDisplay.drop(columns='Tuition_new')
        ForDisplay = ForDisplay.drop(columns='Ratio_New')
        ForDisplay = ForDisplay.drop(columns='Selectivity')
        ForDisplay = ForDisplay.drop(columns= 'StateLocation')
        NoteForNone="Hmm...There aren't any schools that completely match your needs and preferences. But here are schools that matches your academic performance based on your GPA." 

    # Display only the max number of recommendations that the students would like to see
    if Student_TopSchools=='Top10':
        ForDisplay=ForDisplay.head(10)
    elif Student_TopSchools=='Top15':
        ForDisplay=ForDisplay.head(15)
    elif Student_TopSchools=='Top20':
        ForDisplay=ForDisplay.head(20)

    #Return the post filtering table to the Recommenations html file for user interface displaying
    return render_template('Recommendation.html',tables=[ForDisplay.to_html (classes='Outputs')],titles = ['College Recommendations'],index=None,A=NoteForNone)



# start the server with the 'run()' method
if __name__ == '__main__':
    app.run(debug = True)


